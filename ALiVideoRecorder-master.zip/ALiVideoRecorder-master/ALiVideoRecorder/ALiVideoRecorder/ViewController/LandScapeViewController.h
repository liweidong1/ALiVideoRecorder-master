//
//  LandScapeViewController.h
//  ALiVideoRecorder
//
//  Created by LeeWong on 2016/10/12.
//  Copyright © 2016年 LeeWong. All rights reserved.
//

#import "ALiViewController.h"

@interface LandScapeViewController : ALiViewController

@end
