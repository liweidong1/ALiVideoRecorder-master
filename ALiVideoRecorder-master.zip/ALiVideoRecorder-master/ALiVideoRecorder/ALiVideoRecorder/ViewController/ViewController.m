//
//  ViewController.m
//  ALiVideoRecorder
//
//  Created by LeeWong on 2016/10/12.
//  Copyright © 2016年 LeeWong. All rights reserved.
//

#import "ViewController.h"
#import "ALiVideoRecorder.h"



@interface ViewController ()



@end

@implementation ViewController


@end
